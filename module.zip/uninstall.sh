#!/usr/bin/env sh
MODDIR="${0%/*}"

rm /data/adb/modules_backup.tgz

